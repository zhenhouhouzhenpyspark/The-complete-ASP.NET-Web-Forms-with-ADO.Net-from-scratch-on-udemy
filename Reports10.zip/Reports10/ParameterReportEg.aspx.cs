﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Microsoft.Reporting.WebForms;
using Microsoft.ReportingServices;
using System.Collections.Generic;

public partial class ParameterReportEg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //List<ReportParameter> lp = new List<ReportParameter>();
        //ReportParameter rp = new ReportParameter("did", DropDownList1.SelectedValue.ToString());
        //lp.Add(rp);
        //ReportViewer1.LocalReport.SetParameters(lp);
        //ReportViewer1.LocalReport.Refresh();

        ReportParameter rp = new ReportParameter("did", DropDownList1.SelectedValue.ToString());
        List<ReportParameter> lp = new List<ReportParameter>();
        lp.Add(rp);

        ReportViewer1.LocalReport.SetParameters(lp);
        ReportViewer1.LocalReport.Refresh();
    }
}
